
public class Ques15 {

    
    public static void main(String[] args) {
        int arr1[] = new int []{2,4,6,8,10};
        int arr2[] = new int []{3,5,7,9,11};
        int arr3[] = new int []{6,10,14,18,22};
        
        int rand = (int)Math.round(5*Math.random());
        System.out.println("arr1 :" + arr1[rand]);
        
        rand = (int)Math.round(5*Math.random());
        System.out.println("arr2 : " + arr2[rand]);
        
        rand = (int)Math.round(5*Math.random());
        System.out.println("arr3 :" + arr3[rand]);
        
       
    }
    
}